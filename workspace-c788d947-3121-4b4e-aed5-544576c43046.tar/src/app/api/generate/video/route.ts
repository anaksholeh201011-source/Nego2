import { NextRequest, NextResponse } from 'next/server'
import { generateJSON, getZAI } from '@/lib/zai'
import { db } from '@/lib/db'

export interface VideoScene {
  id: number
  imagePrompt: string
  caption: string
  duration: number // seconds to show
  transition: 'fade' | 'slide' | 'zoom'
}

export interface VideoStoryboard {
  title: string
  description: string
  style: string
  aspectRatio: '16:9' | '9:16' | '1:1'
  scenes: VideoScene[]
  audioNarration: string
}

const SYSTEM_PROMPT = `You are a professional AI film director. You output a JSON storyboard for a short video.

The JSON shape MUST be exactly:
{
  "title": string,
  "description": string,
  "style": string,
  "aspectRatio": "16:9" | "9:16" | "1:1",
  "scenes": [
    {
      "id": number,
      "imagePrompt": string (detailed visual description for image generation, 1-2 sentences),
      "caption": string (short text overlay shown during this scene),
      "duration": number (3-6 seconds),
      "transition": "fade" | "slide" | "zoom"
    }
  ],
  "audioNarration": string (a 1-2 sentence voiceover narration summary)
}

Rules:
- Always output valid JSON only, no markdown fences.
- Provide 3-6 scenes that together tell a coherent story.
- Image prompts should be visually descriptive, cinematic, with lighting and mood.
- Captions should be short and evocative (max 8 words).
- Total duration should be 15-30 seconds.`

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { prompt, style, aspectRatio, sceneCount } = body as {
      prompt: string
      style?: string
      aspectRatio?: '16:9' | '9:16' | '1:1'
      sceneCount?: number
    }

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'prompt is required' },
        { status: 400 }
      )
    }

    const userPrompt = `Create a video storyboard for: "${prompt}".
Visual style: ${style || 'cinematic, photorealistic'}
Aspect ratio: ${aspectRatio || '16:9'}
Number of scenes: ${sceneCount || 4}

Return only the JSON object.`

    const storyboard = await generateJSON<VideoStoryboard>(
      SYSTEM_PROMPT,
      userPrompt,
      { temperature: 0.85 }
    )

    if (!storyboard.scenes || !Array.isArray(storyboard.scenes) || storyboard.scenes.length === 0) {
      return NextResponse.json(
        { error: 'Invalid storyboard returned by model' },
        { status: 500 }
      )
    }

    // Map aspect ratio to image size
    const sizeMap: Record<string, string> = {
      '16:9': '1344x768',
      '9:16': '768x1344',
      '1:1': '1024x1024',
    }
    const size = sizeMap[storyboard.aspectRatio] || '1344x768'

    // Generate images for each scene in parallel
    const zai = await getZAI()
    const sceneResults = await Promise.all(
      storyboard.scenes.map(async (scene) => {
        try {
          const imgResp = await zai.images.generations.create({
            prompt: `${scene.imagePrompt}, ${storyboard.style} style, cinematic lighting, high detail`,
            size: size as '1024x1024' | '768x1344' | '864x1152' | '1344x768' | '1152x864' | '1440x720' | '720x1440',
          })
          const base64 = imgResp.data?.[0]?.base64 || ''
          return {
            ...scene,
            imageBase64: base64 ? `data:image/png;base64,${base64}` : '',
          }
        } catch (err) {
          console.error(`Failed to generate image for scene ${scene.id}:`, err)
          return { ...scene, imageBase64: '' }
        }
      })
    )

    const finalStoryboard = { ...storyboard, scenes: sceneResults }

    try {
      await db.generation.create({
        data: {
          type: 'video',
          prompt,
          params: JSON.stringify({ style, aspectRatio, sceneCount }),
          result: JSON.stringify({
            title: storyboard.title,
            description: storyboard.description,
            sceneCount: sceneResults.length,
          }),
        },
      })
    } catch {
      // best-effort
    }

    return NextResponse.json({ storyboard: finalStoryboard })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[/api/generate/video]', err)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
