import { NextRequest, NextResponse } from 'next/server'
import { getZAI } from '@/lib/zai'
import { db } from '@/lib/db'

export interface GameResult {
  title: string
  description: string
  genre: string
  controls: string
  html: string
}

const SYSTEM_PROMPT = `You are an expert HTML5 game developer. You output a JSON object containing a complete, self-contained, runnable HTML5 game.

CRITICAL CONSTRAINTS:
1. The complete JSON output MUST be under 5000 characters total. This is a hard limit.
2. The "html" field must be a complete HTML document but kept MINIMAL and COMPACT.
3. Remove all comments, unnecessary whitespace, and use short variable names in the JS.
4. Keep CSS minimal - only what's needed for the game to look decent.
5. The game must be FUN and PLAYABLE despite being compact.

JSON shape:
{
  "title": string (max 40 chars),
  "description": string (max 100 chars),
  "genre": string,
  "controls": string (max 60 chars),
  "html": string (complete HTML document, COMPACT, max 4500 chars)
}

HTML requirements:
- Must start with <!DOCTYPE html> and end with </html>
- All JS in <script> tags, all CSS in <style> tags (no external imports)
- Use <canvas> for rendering
- Vanilla JS only (no libraries)
- Include: start screen, gameplay loop, scoring, game-over state
- Keyboard controls (arrows/WASD/space)
- Web Audio API for sound effects (no external files)
- Canvas size ~700x500, responsive
- PROPERLY ESCAPE all special characters in JSON: \\" for quotes, \\\\ for backslash, \\n for newlines in strings

OUTPUT ONLY the JSON object. No markdown fences, no explanations.`

const GAME_TEMPLATES: Record<string, string> = {
  shooter: 'spaceship shooter (player at bottom shoots enemies coming from top)',
  platformer: 'platform jumper (player jumps between platforms collecting coins)',
  snake: 'snake game (player controls growing snake eating food)',
  breakout: 'breakout (paddle hits ball to break bricks)',
  dodge: 'dodge game (player avoids falling obstacles)',
  maze: 'maze runner (player navigates maze to exit)',
  collector: 'collector game (player collects items avoiding enemies)',
  puzzle: 'match puzzle (simple tile matching)',
}

/**
 * Attempts to repair a truncated JSON response from the LLM by extracting
 * the HTML field even if the overall JSON is malformed.
 */
function repairGameJson(raw: string): GameResult | null {
  // Strip code fences
  const fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/i)
  const text = fence ? fence[1] : raw

  // Try clean parse first
  try {
    const obj = JSON.parse(text)
    if (obj.html) return obj
  } catch {
    // continue
  }

  // Extract fields with regex
  const getString = (key: string): string => {
    const re = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`, 'm')
    const m = text.match(re)
    if (!m) return ''
    try {
      return JSON.parse(`"${m[1]}"`)
    } catch {
      return m[1]
    }
  }

  // For html, the value may contain escaped newlines and quotes
  const getHtml = (): string => {
    const startIdx = text.search(/"html"\s*:\s*"/)
    if (startIdx === -1) return ''
    const valueStart = text.indexOf('"', startIdx + 6) + 1
    let i = valueStart
    let result = ''
    while (i < text.length) {
      const ch = text[i]
      if (ch === '\\' && i + 1 < text.length) {
        const next = text[i + 1]
        if (next === 'n') result += '\n'
        else if (next === 't') result += '\t'
        else if (next === 'r') result += '\r'
        else if (next === '"') result += '"'
        else if (next === '\\') result += '\\'
        else if (next === '/') result += '/'
        else result += next
        i += 2
      } else if (ch === '"') {
        // End of string
        break
      } else {
        result += ch
        i++
      }
    }
    return result
  }

  const html = getHtml()
  if (!html || html.length < 200) return null

  return {
    title: getString('title') || 'AI Game',
    description: getString('description') || 'AI-generated game',
    genre: getString('genre') || 'arcade',
    controls: getString('controls') || 'Arrow keys + Space',
    html,
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { prompt, gameType } = body as {
      prompt: string
      gameType?: string
    }

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'prompt is required' },
        { status: 400 }
      )
    }

    const gameHint = gameType && GAME_TEMPLATES[gameType]
      ? `Base it on a ${GAME_TEMPLATES[gameType]}.`
      : 'Choose a simple but fun arcade game style.'

    const userPrompt = `Create an HTML5 game: "${prompt}".
${gameHint}
Keep the HTML under 4500 characters. Compact, no comments, minimal CSS.
Output only the JSON object.`

    const zai = await getZAI()

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userPrompt },
      ],
      thinking: { type: 'disabled' },
      temperature: 0.6,
    })

    const raw = completion.choices?.[0]?.message?.content ?? ''
    let game: GameResult | null = null

    // Try strict JSON first
    try {
      const parsed = JSON.parse(raw)
      if (parsed.html) game = parsed
    } catch {
      // fall through to repair
    }

    // Try repair
    if (!game) {
      game = repairGameJson(raw)
    }

    // Final fallback: minimal built-in game
    if (!game || !game.html || game.html.length < 200) {
      game = {
        title: 'Fallback Snake',
        description: 'The AI could not generate your game in time. Here is a built-in Snake game instead.',
        genre: 'arcade',
        controls: 'Arrow keys to move',
        html: `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Snake</title><style>body{margin:0;background:#0f172a;color:#fff;font-family:monospace;display:flex;flex-direction:column;align-items:center;padding:16px}canvas{background:#1e293b;border:2px solid #6366f1;border-radius:8px}h1{font-size:18px;margin:8px 0}#s{font-size:14px;color:#a5b4fc;margin-bottom:8px}</style></head><body><h1>Fallback Snake</h1><div id="s">Score: 0</div><canvas id="c" width="500" height="500"></canvas><p>Use arrow keys. Eat the red food.</p><script>
const c=document.getElementById('c');const x=c.getContext('2d');const G=20;let s=[{x:10,y:10}],d={x:1,y:0},f={x:5,y:5},sc=0,r=null;
function R(){x.fillStyle('#1e293b');x.fillRect(0,0,500,500);x.fillStyle='#ef4444';x.fillRect(f.x*G,f.y*G,G-2,G-2);x.fillStyle='#22d3ee';s.forEach(p=>x.fillRect(p.x*G,p.y*G,G-2,G-2));}
function U(){const h={x:s[0].x+d.x,y:s[0].y+d.y};if(h.x<0||h.x>=25||h.y<0||h.y>=25||s.some(p=>p.x==h.x&&p.y==h.y)){clearInterval(r);x.fillStyle='#fff';x.font='24px monospace';x.fillText('Game Over! Score: '+sc,80,250);return;}s.unshift(h);if(h.x==f.x&&h.y==f.y){sc++;document.getElementById('s').textContent='Score: '+sc;f={x:Math.floor(Math.random()*25),y:Math.floor(Math.random()*25)};}else s.pop();R();}
document.addEventListener('keydown',e=>{const k=e.key;if(k=='ArrowUp'&&d.y!=1)d={x:0,y:-1};if(k=='ArrowDown'&&d.y!=-1)d={x:0,y:1};if(k=='ArrowLeft'&&d.x!=1)d={x:-1,y:0};if(k=='ArrowRight'&&d.x!=-1)d={x:1,y:0};});
R();r=setInterval(U,120);
</script></body></html>`,
      }
    }

    try {
      await db.generation.create({
        data: {
          type: 'game',
          prompt,
          params: JSON.stringify({ gameType }),
          result: JSON.stringify({
            title: game.title,
            description: game.description,
            genre: game.genre,
            htmlLength: game.html.length,
          }),
        },
      })
    } catch {
      // best-effort
    }

    return NextResponse.json({ game })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[/api/generate/game]', err)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
