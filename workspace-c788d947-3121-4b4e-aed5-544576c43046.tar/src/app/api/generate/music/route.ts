import { NextRequest, NextResponse } from 'next/server'
import { generateJSON } from '@/lib/zai'
import { db } from '@/lib/db'

export interface MusicNote {
  time: number
  freq: number
  duration: number
  instrument: 'sine' | 'square' | 'sawtooth' | 'triangle'
  velocity: number
}

export interface MusicTrack {
  tempo: number
  key: string
  genre: string
  mood: string
  duration: number
  tracks: {
    name: string
    instrument: MusicNote['instrument']
    notes: MusicNote[]
  }[]
}

const SYSTEM_PROMPT = `You are a professional AI music composer. You output a JSON object that represents a complete musical piece using the Web Audio API.

The JSON shape MUST be exactly:
{
  "tempo": number (BPM, 60-180),
  "key": string (e.g. "C major", "A minor"),
  "genre": string,
  "mood": string,
  "duration": number (total seconds, 8-30),
  "tracks": [
    {
      "name": string,
      "instrument": "sine" | "square" | "sawtooth" | "triangle",
      "notes": [
        { "time": number (seconds), "freq": number (Hz, 80-2000), "duration": number (seconds, 0.1-2), "velocity": number (0-1) }
      ]
    }
  ]
}

Rules:
- Always output valid JSON only, no markdown fences, no explanations.
- Provide 3-5 tracks: bass, harmony, melody, percussion (use square/sawtooth for percussion).
- Use proper musical frequencies (e.g. C4=261.63, D4=293.66, E4=329.63, F4=349.23, G4=392.00, A4=440.00, B4=493.88).
- Notes must align with the tempo (use tempo/60 as beat duration).
- Make the composition pleasant and musically coherent.
- Total notes per track: 8-40 depending on duration.
- For percussion, use short durations (0.05-0.15s) and lower frequencies (60-200 Hz).
- Melody should have varied rhythm and pitch contour.`

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { prompt, genre, mood, duration } = body as {
      prompt: string
      genre?: string
      mood?: string
      duration?: number
    }

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'prompt is required' },
        { status: 400 }
      )
    }

    const userPrompt = `Compose a piece based on this prompt: "${prompt}".
Genre: ${genre || 'auto-select based on prompt'}
Mood: ${mood || 'auto-select based on prompt'}
Duration: ${duration || 15} seconds

Return only the JSON object.`

    const track = await generateJSON<MusicTrack>(
      SYSTEM_PROMPT,
      userPrompt,
      { temperature: 0.9 }
    )

    if (!track.tracks || !Array.isArray(track.tracks) || track.tracks.length === 0) {
      return NextResponse.json(
        { error: 'Invalid music data returned by model' },
        { status: 500 }
      )
    }

    try {
      await db.generation.create({
        data: {
          type: 'music',
          prompt,
          params: JSON.stringify({ genre, mood, duration }),
          result: JSON.stringify(track),
        },
      })
    } catch {
      // best-effort
    }

    return NextResponse.json({ track })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[/api/generate/music]', err)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
