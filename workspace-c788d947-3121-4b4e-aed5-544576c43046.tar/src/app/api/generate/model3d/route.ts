import { NextRequest, NextResponse } from 'next/server'
import { generateJSON } from '@/lib/zai'
import { db } from '@/lib/db'

export interface Model3DObject {
  type: 'box' | 'sphere' | 'cylinder' | 'cone' | 'torus' | 'plane' | 'octahedron' | 'icosahedron' | 'torusKnot'
  position: [number, number, number]
  rotation: [number, number, number]
  scale: [number, number, number] | number
  color: string // hex color
  material: 'standard' | 'phong' | 'basic' | 'wireframe'
  metalness?: number // 0-1
  roughness?: number // 0-1
}

export interface Model3DScene {
  name: string
  description: string
  background: string // hex color
  ambientLight: number // 0-2
  directionalLight: number // 0-2
  cameraPosition: [number, number, number]
  cameraTarget: [number, number, number]
  autoRotate: boolean
  rotateSpeed: number
  objects: Model3DObject[]
}

const SYSTEM_PROMPT = `You are an expert 3D scene designer using Three.js. You output a JSON object describing a 3D scene built from primitive geometries.

The JSON shape MUST be exactly:
{
  "name": string,
  "description": string,
  "background": string (hex color like "#1a1a2e"),
  "ambientLight": number (0-2, intensity),
  "directionalLight": number (0-2, intensity),
  "cameraPosition": [x, y, z] (numbers),
  "cameraTarget": [x, y, z] (numbers, the look-at target),
  "autoRotate": boolean,
  "rotateSpeed": number (0-5),
  "objects": [
    {
      "type": "box" | "sphere" | "cylinder" | "cone" | "torus" | "plane" | "octahedron" | "icosahedron" | "torusKnot",
      "position": [x, y, z],
      "rotation": [x, y, z] (radians),
      "scale": [x, y, z] OR number (uniform scale),
      "color": string (hex like "#ff6b6b"),
      "material": "standard" | "phong" | "basic" | "wireframe",
      "metalness": number (0-1, optional),
      "roughness": number (0-1, optional)
    }
  ]
}

Rules:
- Always output valid JSON only, no markdown fences.
- Build a recognizable, aesthetically pleasing 3D scene from primitives (e.g. "cat" = sphere body + box legs + cone ears + sphere head + cylinder tail).
- Use 5-25 objects.
- Keep positions within [-5, 5] range.
- Use varied colors that fit the theme.
- Default scale to 1 if using uniform scaling.
- The scene should be interpretable as the prompt concept.
- Always include a ground plane (type: "plane", rotation: [-1.5708, 0, 0], position: [0, -1, 0], scale: [10, 10, 1]) unless the concept is abstract.`

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { prompt, complexity } = body as {
      prompt: string
      complexity?: 'low' | 'medium' | 'high'
    }

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'prompt is required' },
        { status: 400 }
      )
    }

    const targetObjects =
      complexity === 'low' ? '5-10' : complexity === 'high' ? '15-25' : '8-15'

    const userPrompt = `Build a 3D model/scene based on this prompt: "${prompt}".
Complexity: ${complexity || 'medium'} (target ${targetObjects} objects).

Return only the JSON object.`

    const scene = await generateJSON<Model3DScene>(
      SYSTEM_PROMPT,
      userPrompt,
      { temperature: 0.8 }
    )

    if (!scene.objects || !Array.isArray(scene.objects) || scene.objects.length === 0) {
      return NextResponse.json(
        { error: 'Invalid 3D scene returned by model' },
        { status: 500 }
      )
    }

    try {
      await db.generation.create({
        data: {
          type: 'model3d',
          prompt,
          params: JSON.stringify({ complexity }),
          result: JSON.stringify({
            name: scene.name,
            description: scene.description,
            objectCount: scene.objects.length,
          }),
        },
      })
    } catch {
      // best-effort
    }

    return NextResponse.json({ scene })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[/api/generate/model3d]', err)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
