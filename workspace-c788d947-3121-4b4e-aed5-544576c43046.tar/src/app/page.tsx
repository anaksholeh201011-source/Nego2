'use client'

import * as React from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Music, Video, Gamepad2, Box, Github, Moon, Sun, Sparkles, Zap, Wand2 } from 'lucide-react'
import { MusicGenerator } from '@/components/generators/music-generator'
import { VideoGenerator } from '@/components/generators/video-generator'
import { GameGenerator } from '@/components/generators/game-generator'
import { Model3DGenerator } from '@/components/generators/model3d-generator'
import { useTheme } from 'next-themes'
import { motion } from 'framer-motion'

const TABS = [
  { id: 'music', label: 'Music', icon: Music, desc: 'Compose multi-track audio from a text prompt' },
  { id: 'video', label: 'Video', icon: Video, desc: 'Storyboard and render cinematic scenes' },
  { id: 'game', label: 'Game', icon: Gamepad2, desc: 'Generate a playable HTML5 game instantly' },
  { id: 'model3d', label: '3D Model', icon: Box, desc: 'Sculpt interactive 3D scenes from primitives' },
] as const

export default function Home() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)
  React.useEffect(() => setMounted(true), [])

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="size-9 rounded-lg bg-gradient-to-br from-primary via-fuchsia-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-primary/30">
                <Sparkles className="size-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-base leading-tight">NexusAI Studio</div>
                <div className="text-[10px] text-muted-foreground leading-tight">Generate Anything</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                aria-label="Toggle theme"
              >
                {mounted && theme === 'dark' ? <Sun className="size-4" /> : <Moon className="size-4" />}
              </Button>
              <Button asChild variant="outline" size="sm">
                <a href="https://github.com" target="_blank" rel="noreferrer">
                  <Github className="size-4" />
                  <span className="hidden sm:inline">GitHub</span>
                </a>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border/40">
        <div className="absolute inset-0 hero-gradient" />
        <div className="absolute inset-0 grid-bg opacity-50" />
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 relative">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center text-center gap-4"
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/60 px-3 py-1 text-xs font-medium backdrop-blur">
              <Zap className="size-3.5 text-primary" />
              Powered by GLM multimodal AI
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold tracking-tight max-w-3xl">
              One AI studio for{' '}
              <span className="bg-gradient-to-r from-primary via-fuchsia-500 to-cyan-500 bg-clip-text text-transparent">
                everything you create
              </span>
            </h1>
            <p className="max-w-2xl text-sm sm:text-base text-muted-foreground">
              Generate music, videos, playable games, and interactive 3D models — all from a single text prompt.
              No installs, no plugins. Just describe it and watch it come to life.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
              {TABS.map((t) => (
                <div
                  key={t.id}
                  className="inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-background/60 px-2.5 py-1 text-xs font-medium backdrop-blur"
                >
                  <t.icon className="size-3.5 text-primary" />
                  {t.label}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Main */}
      <main className="flex-1">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <Tabs defaultValue="music" className="w-full">
            <div className="flex justify-center mb-6">
              <TabsList className="grid w-full max-w-2xl grid-cols-4 h-auto p-1">
                {TABS.map((t) => (
                  <TabsTrigger key={t.id} value={t.id} className="flex flex-col items-center gap-1 py-2.5 px-2 sm:flex-row sm:gap-2">
                    <t.icon className="size-4" />
                    <span className="text-xs sm:text-sm">{t.label}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {TABS.map((t) => (
              <TabsContent key={t.id} value={t.id} className="mt-0">
                <div className="mb-5">
                  <div className="flex items-center gap-2 mb-1">
                    <Wand2 className="size-4 text-primary" />
                    <h2 className="text-lg font-semibold">{t.label} Generator</h2>
                  </div>
                  <p className="text-sm text-muted-foreground">{t.desc}</p>
                </div>
                {t.id === 'music' && <MusicGenerator />}
                {t.id === 'video' && <VideoGenerator />}
                {t.id === 'game' && <GameGenerator />}
                {t.id === 'model3d' && <Model3DGenerator />}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/40 bg-background/60">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <Sparkles className="size-3.5 text-primary" />
              <span>NexusAI Studio · Open-source AI creation platform</span>
            </div>
            <div className="flex items-center gap-4">
              <span>Built with Next.js, Three.js, Web Audio & GLM</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
