import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NexusAI Studio — Generate Anything",
  description:
    "All-in-one AI creation studio. Generate music, videos, games, and 3D models from text prompts.",
  keywords: [
    "AI",
    "Generate",
    "Music AI",
    "Video AI",
    "Game AI",
    "3D Model AI",
    "Creative AI",
  ],
  authors: [{ name: "NexusAI" }],
  openGraph: {
    title: "NexusAI Studio — Generate Anything",
    description:
      "All-in-one AI creation studio. Generate music, videos, games, and 3D models from text prompts.",
    siteName: "NexusAI Studio",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster richColors position="top-right" />
        </ThemeProvider>
      </body>
    </html>
  );
}
