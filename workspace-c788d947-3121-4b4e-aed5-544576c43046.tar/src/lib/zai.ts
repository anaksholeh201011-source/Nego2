import ZAI from 'z-ai-web-dev-sdk'

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null

export async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

/**
 * Calls the LLM and extracts a JSON object from the response.
 * Falls back gracefully if the model wraps JSON in code fences.
 */
export async function generateJSON<T = unknown>(
  systemPrompt: string,
  userPrompt: string,
  options: { temperature?: number } = {}
): Promise<T> {
  const zai = await getZAI()

  const completion = await zai.chat.completions.create({
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    thinking: { type: 'disabled' },
    temperature: options.temperature ?? 0.8,
  })

  const content = completion.choices?.[0]?.message?.content ?? ''
  return extractJSON<T>(content)
}

export function extractJSON<T>(text: string): T {
  // Strip code fences if present
  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/i)
  const cleaned = fenceMatch ? fenceMatch[1] : text

  // Find the first { ... } or [ ... ] block
  const objMatch = cleaned.match(/\{[\s\S]*\}/)
  const arrMatch = cleaned.match(/\[[\s\S]*\]/)

  let candidate: string | null = null
  if (objMatch && arrMatch) {
    candidate = (objMatch.index ?? 0) < (arrMatch.index ?? 0) ? objMatch[0] : arrMatch[0]
  } else if (objMatch) {
    candidate = objMatch[0]
  } else if (arrMatch) {
    candidate = arrMatch[0]
  }

  if (!candidate) {
    throw new Error('No JSON found in LLM response')
  }

  return JSON.parse(candidate) as T
}
