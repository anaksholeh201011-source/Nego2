'use client'

import * as React from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Gamepad2, Loader2, Sparkles, Download, RotateCcw, Code2 } from 'lucide-react'
import { toast } from 'sonner'

interface GameResult {
  title: string
  description: string
  genre: string
  controls: string
  html: string
}

export function GameGenerator() {
  const [prompt, setPrompt] = React.useState('A space shooter where you defend Earth from alien invaders')
  const [gameType, setGameType] = React.useState('auto')
  const [loading, setLoading] = React.useState(false)
  const [game, setGame] = React.useState<GameResult | null>(null)
  const [showCode, setShowCode] = React.useState(false)
  const iframeRef = React.useRef<HTMLIFrameElement | null>(null)
  const [iframeKey, setIframeKey] = React.useState(0)

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt first')
      return
    }
    setLoading(true)
    setGame(null)
    setShowCode(false)
    try {
      const res = await fetch('/api/generate/game', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          gameType: gameType === 'auto' ? undefined : gameType,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to generate game')
      setGame(data.game)
      setIframeKey((k) => k + 1)
      toast.success(`Generated "${data.game.title}"`)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  const handleRestart = () => {
    setIframeKey((k) => k + 1)
    toast.success('Game restarted')
  }

  const handleDownload = () => {
    if (!game) return
    const blob = new Blob([game.html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${game.title.toLowerCase().replace(/\s+/g, '-')}.html`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Game HTML downloaded')
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gamepad2 className="size-5 text-primary" />
            Game Designer
          </CardTitle>
          <CardDescription>
            Describe a game and the AI will generate a complete, playable HTML5 game (vanilla JS + canvas) that runs instantly.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="game-prompt">Prompt</Label>
            <Textarea
              id="game-prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A flappy bird style game with dragons flying through pipes"
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Game Type</Label>
            <Select value={gameType} onValueChange={setGameType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Auto-select</SelectItem>
                <SelectItem value="shooter">Shooter</SelectItem>
                <SelectItem value="platformer">Platformer</SelectItem>
                <SelectItem value="snake">Snake-like</SelectItem>
                <SelectItem value="breakout">Breakout</SelectItem>
                <SelectItem value="dodge">Dodge/Avoid</SelectItem>
                <SelectItem value="maze">Maze</SelectItem>
                <SelectItem value="collector">Collector</SelectItem>
                <SelectItem value="puzzle">Puzzle</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerate} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Coding game...
              </>
            ) : (
              <>
                <Sparkles className="size-4" />
                Generate Game
              </>
            )}
          </Button>
          <p className="text-xs text-muted-foreground">
            Note: The AI generates a complete HTML5 game from scratch. Generation may take 15-30 seconds.
          </p>

          {game && (
            <div className="space-y-3 pt-2 border-t border-border/60">
              <div>
                <div className="text-sm font-medium">{game.title}</div>
                <div className="text-xs text-muted-foreground">{game.description}</div>
              </div>
              <div className="flex flex-wrap gap-2 text-xs">
                <Badge variant="outline">{game.genre}</Badge>
                <Badge variant="secondary">{game.controls}</Badge>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleRestart}>
                  <RotateCcw className="size-4" />
                  Restart
                </Button>
                <Button variant="outline" size="sm" onClick={handleDownload}>
                  <Download className="size-4" />
                  Download HTML
                </Button>
                <Button variant="outline" size="sm" onClick={() => setShowCode((s) => !s)}>
                  <Code2 className="size-4" />
                  {showCode ? 'Hide' : 'View'} Code
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gamepad2 className="size-5 text-primary" />
            Playable Game
          </CardTitle>
          <CardDescription>
            {game ? 'Click the game area to focus, then use the controls.' : 'Your generated game will appear here.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!game && !loading && (
            <div className="flex flex-col items-center justify-center h-72 text-center text-muted-foreground">
              <Gamepad2 className="size-12 mb-3 opacity-30" />
              <p className="text-sm">Generate a game to start playing.</p>
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center h-72 gap-3">
              <Loader2 className="size-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">AI is writing game code...</p>
            </div>
          )}

          {game && (
            <div className="space-y-3">
              <div className="relative bg-black rounded-lg overflow-hidden border border-border/60">
                <iframe
                  key={iframeKey}
                  ref={iframeRef}
                  srcDoc={game.html}
                  title={game.title}
                  className="w-full h-[600px] block"
                  sandbox="allow-scripts allow-pointer-lock"
                />
              </div>

              {showCode && (
                <details className="rounded-md bg-muted/40 p-2">
                  <summary className="text-xs font-medium cursor-pointer">Source code ({game.html.length} chars)</summary>
                  <pre className="text-[10px] mt-2 max-h-48 overflow-auto nice-scroll font-mono whitespace-pre-wrap break-all">
                    {game.html}
                  </pre>
                </details>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
