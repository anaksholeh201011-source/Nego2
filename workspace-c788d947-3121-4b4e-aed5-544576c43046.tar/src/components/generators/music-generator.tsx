'use client'

import * as React from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Play, Pause, Download, Loader2, Music, Sparkles } from 'lucide-react'
import { toast } from 'sonner'

interface MusicNote {
  time: number
  freq: number
  duration: number
  instrument: 'sine' | 'square' | 'sawtooth' | 'triangle'
  velocity: number
}

interface MusicTrack {
  tempo: number
  key: string
  genre: string
  mood: string
  duration: number
  tracks: {
    name: string
    instrument: MusicNote['instrument']
    notes: MusicNote[]
  }[]
}

export function MusicGenerator() {
  const [prompt, setPrompt] = React.useState('A dreamy lo-fi hip hop beat for studying on a rainy night')
  const [genre, setGenre] = React.useState('auto')
  const [mood, setMood] = React.useState('auto')
  const [duration, setDuration] = React.useState(15)
  const [loading, setLoading] = React.useState(false)
  const [track, setTrack] = React.useState<MusicTrack | null>(null)
  const [isPlaying, setIsPlaying] = React.useState(false)
  const [progress, setProgress] = React.useState(0)

  const audioCtxRef = React.useRef<AudioContext | null>(null)
  const activeNodesRef = React.useRef<AudioNode[]>([])
  const playTimerRef = React.useRef<ReturnType<typeof setInterval> | null>(null)
  const startTimeRef = React.useRef(0)

  const ensureAudio = () => {
    if (!audioCtxRef.current) {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      audioCtxRef.current = new Ctx()
    }
    return audioCtxRef.current!
  }

  const stopAll = React.useCallback(() => {
    activeNodesRef.current.forEach((n) => {
      try { (n as OscillatorNode).stop?.() } catch { /* noop */ }
      try { (n as AudioNode).disconnect?.() } catch { /* noop */ }
    })
    activeNodesRef.current = []
    if (playTimerRef.current) {
      clearInterval(playTimerRef.current)
      playTimerRef.current = null
    }
    setIsPlaying(false)
    setProgress(0)
  }, [])

  React.useEffect(() => () => stopAll(), [stopAll])

  const playNote = (ctx: AudioContext, note: MusicNote, instrument: MusicNote['instrument'], startAt: number) => {
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.type = instrument
    osc.frequency.value = note.freq

    const attack = 0.01
    const decay = 0.05
    const sustain = note.velocity * 0.6
    const release = 0.08

    gain.gain.setValueAtTime(0, startAt)
    gain.gain.linearRampToValueAtTime(note.velocity, startAt + attack)
    gain.gain.linearRampToValueAtTime(sustain, startAt + attack + decay)
    gain.gain.setValueAtTime(sustain, startAt + note.duration - release)
    gain.gain.linearRampToValueAtTime(0, startAt + note.duration)

    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.start(startAt)
    osc.stop(startAt + note.duration + 0.05)

    activeNodesRef.current.push(osc, gain)
  }

  const play = () => {
    if (!track) return
    stopAll()
    const ctx = ensureAudio()
    if (ctx.state === 'suspended') ctx.resume()

    const now = ctx.currentTime + 0.1
    startTimeRef.current = now

    track.tracks.forEach((t) => {
      t.notes.forEach((note) => {
        playNote(ctx, note, t.instrument, now + note.time)
      })
    })

    setIsPlaying(true)

    const total = track.duration
    playTimerRef.current = setInterval(() => {
      const elapsed = ctx.currentTime - now
      setProgress(Math.min(100, (elapsed / total) * 100))
      if (elapsed >= total) {
        stopAll()
      }
    }, 50)
  }

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt first')
      return
    }
    stopAll()
    setLoading(true)
    setTrack(null)
    try {
      const res = await fetch('/api/generate/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          genre: genre === 'auto' ? undefined : genre,
          mood: mood === 'auto' ? undefined : mood,
          duration,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to generate music')
      setTrack(data.track)
      toast.success(`Generated "${data.track.genre}" track in ${data.track.key}`)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = () => {
    if (!track) return
    const blob = new Blob([JSON.stringify(track, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `nexusai-music-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Track data exported')
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="size-5 text-primary" />
            Music Composition
          </CardTitle>
          <CardDescription>
            Describe the music you want and the AI will compose a multi-track piece using Web Audio synthesis.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="music-prompt">Prompt</Label>
            <Textarea
              id="music-prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. An upbeat synthwave track with driving bass and dreamy arpeggios"
              className="min-h-[100px]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Genre</Label>
              <Select value={genre} onValueChange={setGenre}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto-detect</SelectItem>
                  <SelectItem value="lofi">Lo-Fi</SelectItem>
                  <SelectItem value="synthwave">Synthwave</SelectItem>
                  <SelectItem value="orchestral">Orchestral</SelectItem>
                  <SelectItem value="electronic">Electronic</SelectItem>
                  <SelectItem value="ambient">Ambient</SelectItem>
                  <SelectItem value="rock">Rock</SelectItem>
                  <SelectItem value="jazz">Jazz</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Mood</Label>
              <Select value={mood} onValueChange={setMood}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto-detect</SelectItem>
                  <SelectItem value="happy">Happy</SelectItem>
                  <SelectItem value="melancholic">Melancholic</SelectItem>
                  <SelectItem value="epic">Epic</SelectItem>
                  <SelectItem value="relaxed">Relaxed</SelectItem>
                  <SelectItem value="energetic">Energetic</SelectItem>
                  <SelectItem value="mysterious">Mysterious</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Duration: {duration}s</Label>
            <Slider
              value={[duration]}
              onValueChange={(v) => setDuration(v[0])}
              min={8}
              max={30}
              step={1}
            />
          </div>

          <Button onClick={handleGenerate} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Composing...
              </>
            ) : (
              <>
                <Sparkles className="size-4" />
                Generate Music
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Player</span>
            {track && (
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="size-4" />
                Export
              </Button>
            )}
          </CardTitle>
          <CardDescription>
            {track ? `${track.genre} · ${track.key} · ${track.tempo} BPM` : 'Generated track will appear here.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!track && !loading && (
            <div className="flex flex-col items-center justify-center h-72 text-center text-muted-foreground">
              <Music className="size-12 mb-3 opacity-30" />
              <p className="text-sm">Compose a track to start playing.</p>
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center h-72 gap-3">
              <Loader2 className="size-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">AI is composing notes...</p>
            </div>
          )}

          {track && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Button onClick={isPlaying ? stopAll : play} size="lg" className="rounded-full size-14 p-0">
                  {isPlaying ? <Pause className="size-5" /> : <Play className="size-5 ml-0.5" />}
                </Button>
                <div className="flex-1">
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>{(progress / 100 * track.duration).toFixed(1)}s</span>
                    <span>{track.duration}s</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 max-h-64 overflow-y-auto nice-scroll pr-2">
                {track.tracks.map((t, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-md bg-muted/40">
                    <div>
                      <div className="text-sm font-medium">{t.name}</div>
                      <div className="text-xs text-muted-foreground capitalize">{t.instrument} · {t.notes.length} notes</div>
                    </div>
                    <Badge variant="secondary">{t.instrument}</Badge>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                <Badge variant="outline">Genre: {track.genre}</Badge>
                <Badge variant="outline">Mood: {track.mood}</Badge>
                <Badge variant="outline">Key: {track.key}</Badge>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
