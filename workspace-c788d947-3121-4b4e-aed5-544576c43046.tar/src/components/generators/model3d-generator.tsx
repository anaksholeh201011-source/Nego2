'use client'

import * as React from 'react'
import * as THREE from 'three'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2, Sparkles, Box, Download, RotateCcw } from 'lucide-react'
import { toast } from 'sonner'

interface Model3DObject {
  type: 'box' | 'sphere' | 'cylinder' | 'cone' | 'torus' | 'plane' | 'octahedron' | 'icosahedron' | 'torusKnot'
  position: [number, number, number]
  rotation: [number, number, number]
  scale: [number, number, number] | number
  color: string
  material: 'standard' | 'phong' | 'basic' | 'wireframe'
  metalness?: number
  roughness?: number
}

interface Model3DScene {
  name: string
  description: string
  background: string
  ambientLight: number
  directionalLight: number
  cameraPosition: [number, number, number]
  cameraTarget: [number, number, number]
  autoRotate: boolean
  rotateSpeed: number
  objects: Model3DObject[]
}

export function Model3DGenerator() {
  const [prompt, setPrompt] = React.useState('A cute robot with a square head, antenna, and wheel feet')
  const [complexity, setComplexity] = React.useState<'low' | 'medium' | 'high'>('medium')
  const [loading, setLoading] = React.useState(false)
  const [scene, setScene] = React.useState<Model3DScene | null>(null)

  const containerRef = React.useRef<HTMLDivElement | null>(null)
  const threeRef = React.useRef<{
    renderer: THREE.WebGLRenderer
    scene: THREE.Scene
    camera: THREE.PerspectiveCamera
    animationId: number
    controls: { target: THREE.Vector3; autoRotate: boolean; rotateSpeed: number }
  } | null>(null)

  const disposeThree = () => {
    if (threeRef.current) {
      cancelAnimationFrame(threeRef.current.animationId)
      threeRef.current.renderer.dispose()
      threeRef.current.scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose()
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m) => m.dispose())
          } else {
            obj.material.dispose()
          }
        }
      })
      if (containerRef.current && threeRef.current.renderer.domElement.parentElement === containerRef.current) {
        containerRef.current.removeChild(threeRef.current.renderer.domElement)
      }
      threeRef.current = null
    }
  }

  React.useEffect(() => () => disposeThree(), [])

  const buildGeometry = (type: Model3DObject['type']): THREE.BufferGeometry => {
    switch (type) {
      case 'box': return new THREE.BoxGeometry(1, 1, 1)
      case 'sphere': return new THREE.SphereGeometry(0.5, 32, 32)
      case 'cylinder': return new THREE.CylinderGeometry(0.5, 0.5, 1, 32)
      case 'cone': return new THREE.ConeGeometry(0.5, 1, 32)
      case 'torus': return new THREE.TorusGeometry(0.5, 0.2, 16, 32)
      case 'plane': return new THREE.PlaneGeometry(1, 1)
      case 'octahedron': return new THREE.OctahedronGeometry(0.6)
      case 'icosahedron': return new THREE.IcosahedronGeometry(0.6)
      case 'torusKnot': return new THREE.TorusKnotGeometry(0.4, 0.15, 64, 16)
      default: return new THREE.BoxGeometry(1, 1, 1)
    }
  }

  const buildMaterial = (obj: Model3DObject): THREE.Material => {
    const color = obj.color || '#ffffff'
    const metalness = obj.metalness ?? 0.3
    const roughness = obj.roughness ?? 0.5
    if (obj.material === 'wireframe') {
      return new THREE.MeshBasicMaterial({ color, wireframe: true })
    }
    if (obj.material === 'basic') {
      return new THREE.MeshBasicMaterial({ color })
    }
    if (obj.material === 'phong') {
      return new THREE.MeshPhongMaterial({ color, shininess: 60 })
    }
    return new THREE.MeshStandardMaterial({ color, metalness, roughness })
  }

  const renderScene = (sc: Model3DScene) => {
    disposeThree()
    if (!containerRef.current) return

    const width = containerRef.current.clientWidth
    const height = containerRef.current.clientHeight

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false })
    renderer.setPixelRatio(window.devicePixelRatio || 1)
    renderer.setSize(width, height)
    renderer.setClearColor(new THREE.Color(sc.background), 1)
    containerRef.current.appendChild(renderer.domElement)

    const threeScene = new THREE.Scene()
    threeScene.background = new THREE.Color(sc.background)

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100)
    const [cx, cy, cz] = sc.cameraPosition
    camera.position.set(cx, cy, cz)

    const ambient = new THREE.AmbientLight(0xffffff, sc.ambientLight)
    threeScene.add(ambient)

    const dir = new THREE.DirectionalLight(0xffffff, sc.directionalLight)
    dir.position.set(5, 8, 5)
    dir.castShadow = true
    threeScene.add(dir)

    const dir2 = new THREE.DirectionalLight(0x88aaff, sc.directionalLight * 0.3)
    dir2.position.set(-5, 3, -5)
    threeScene.add(dir2)

    sc.objects.forEach((obj) => {
      const geo = buildGeometry(obj.type)
      const mat = buildMaterial(obj)
      const mesh = new THREE.Mesh(geo, mat)
      mesh.position.set(...obj.position)
      mesh.rotation.set(...obj.rotation)
      const s = obj.scale
      if (typeof s === 'number') {
        mesh.scale.setScalar(s)
      } else {
        mesh.scale.set(s[0], s[1], s[2])
      }
      threeScene.add(mesh)
    })

    const target = new THREE.Vector3(...sc.cameraTarget)
    camera.lookAt(target)

    const controls = {
      target,
      autoRotate: sc.autoRotate,
      rotateSpeed: sc.rotateSpeed,
    }

    let lastTime = performance.now()
    let azimuth = 0
    const radius = camera.position.distanceTo(target)

    const animate = (now: number) => {
      const dt = (now - lastTime) / 1000
      lastTime = now

      if (controls.autoRotate) {
        azimuth += dt * controls.rotateSpeed * 0.5
        const cam = camera.position
        const offset = new THREE.Vector3(
          Math.sin(azimuth) * radius,
          cam.y,
          Math.cos(azimuth) * radius
        )
        camera.position.copy(target).add(offset)
        camera.lookAt(target)
      }

      renderer.render(threeScene, camera)
      threeRef.current!.animationId = requestAnimationFrame(animate)
    }

    threeRef.current = {
      renderer,
      scene: threeScene,
      camera,
      animationId: requestAnimationFrame(animate),
      controls,
    }

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current || !threeRef.current) return
      const w = containerRef.current.clientWidth
      const h = containerRef.current.clientHeight
      threeRef.current.renderer.setSize(w, h)
      threeRef.current.camera.aspect = w / h
      threeRef.current.camera.updateProjectionMatrix()
    }
    window.addEventListener('resize', handleResize)
  }

  // Mouse drag to orbit
  React.useEffect(() => {
    const el = containerRef.current
    if (!el || !threeRef.current) return

    let isDragging = false
    let lastX = 0
    let lastY = 0

    const onDown = (e: MouseEvent) => {
      isDragging = true
      lastX = e.clientX
      lastY = e.clientY
    }
    const onMove = (e: MouseEvent) => {
      if (!isDragging || !threeRef.current) return
      const dx = e.clientX - lastX
      const dy = e.clientY - lastY
      lastX = e.clientX
      lastY = e.clientY

      const cam = threeRef.current.camera
      const target = threeRef.current.controls.target
      const offset = cam.position.clone().sub(target)
      const spherical = new THREE.Spherical().setFromVector3(offset)
      spherical.theta -= dx * 0.005
      spherical.phi -= dy * 0.005
      spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi))
      offset.setFromSpherical(spherical)
      cam.position.copy(target).add(offset)
      cam.lookAt(target)
    }
    const onUp = () => { isDragging = false }

    el.addEventListener('mousedown', onDown)
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    return () => {
      el.removeEventListener('mousedown', onDown)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
  }, [scene])

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt first')
      return
    }
    setLoading(true)
    setScene(null)
    try {
      const res = await fetch('/api/generate/model3d', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, complexity }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to generate 3D model')
      setScene(data.scene)
      // Render after state update
      setTimeout(() => renderScene(data.scene), 50)
      toast.success(`Generated "${data.scene.name}" with ${data.scene.objects.length} objects`)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    if (scene) {
      renderScene(scene)
      toast.success('Camera reset')
    }
  }

  const handleExport = () => {
    if (!scene) return
    const blob = new Blob([JSON.stringify(scene, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `nexusai-3d-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Scene exported')
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Box className="size-5 text-primary" />
            3D Model Designer
          </CardTitle>
          <CardDescription>
            Describe any 3D object or scene. The AI will compose it from Three.js primitives and render an interactive model you can orbit, pan, and inspect.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="model-prompt">Prompt</Label>
            <Textarea
              id="model-prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A futuristic city with skyscrapers and a flying car"
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Complexity</Label>
            <Select value={complexity} onValueChange={(v) => setComplexity(v as 'low' | 'medium' | 'high')}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low (5-10 objects)</SelectItem>
                <SelectItem value="medium">Medium (8-15 objects)</SelectItem>
                <SelectItem value="high">High (15-25 objects)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleGenerate} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Building 3D scene...
              </>
            ) : (
              <>
                <Sparkles className="size-4" />
                Generate 3D Model
              </>
            )}
          </Button>
          <p className="text-xs text-muted-foreground">
            Tip: After rendering, click and drag on the 3D view to orbit the camera.
          </p>

          {scene && (
            <div className="space-y-3 pt-2 border-t border-border/60">
              <div>
                <div className="text-sm font-medium">{scene.name}</div>
                <div className="text-xs text-muted-foreground">{scene.description}</div>
              </div>
              <div className="flex flex-wrap gap-2 text-xs">
                <Badge variant="outline">{scene.objects.length} objects</Badge>
                <Badge variant="outline" className="font-mono">bg {scene.background}</Badge>
                {scene.autoRotate && <Badge variant="secondary">Auto-rotate</Badge>}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleReset}>
                  <RotateCcw className="size-4" />
                  Reset Camera
                </Button>
                <Button variant="outline" size="sm" onClick={handleExport}>
                  <Download className="size-4" />
                  Export Scene
                </Button>
              </div>

              <div className="rounded-md bg-muted/40 p-3 max-h-48 overflow-y-auto nice-scroll">
                <div className="text-xs text-muted-foreground mb-1">Object list</div>
                <div className="space-y-1">
                  {scene.objects.map((o, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span className="size-3 rounded-sm border" style={{ background: o.color }} />
                      <span className="font-mono capitalize">{o.type}</span>
                      <span className="text-muted-foreground">[{o.position.map((n) => n.toFixed(1)).join(', ')}]</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Box className="size-5 text-primary" />
            3D Viewport
          </CardTitle>
          <CardDescription>
            {scene ? 'Drag to orbit · scroll background objects' : 'Your 3D model will render here.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!scene && !loading && (
            <div className="flex flex-col items-center justify-center h-96 text-center text-muted-foreground">
              <Box className="size-12 mb-3 opacity-30" />
              <p className="text-sm">Generate a 3D model to view.</p>
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center h-96 gap-3">
              <Loader2 className="size-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Assembling 3D primitives...</p>
            </div>
          )}

          <div
            ref={containerRef}
            className={`w-full h-96 bg-black rounded-lg overflow-hidden border border-border/60 ${!scene && !loading ? 'hidden' : ''}`}
            style={{ cursor: 'grab' }}
          />
        </CardContent>
      </Card>
    </div>
  )
}
