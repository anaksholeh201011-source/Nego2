'use client'

import * as React from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Play, Pause, Download, Loader2, Video, Sparkles, Film } from 'lucide-react'
import { toast } from 'sonner'

interface VideoScene {
  id: number
  imagePrompt: string
  caption: string
  duration: number
  transition: 'fade' | 'slide' | 'zoom'
  imageBase64: string
}

interface VideoStoryboard {
  title: string
  description: string
  style: string
  aspectRatio: '16:9' | '9:16' | '1:1'
  scenes: VideoScene[]
  audioNarration: string
}

export function VideoGenerator() {
  const [prompt, setPrompt] = React.useState('A day in the life of a cyberpunk street cat')
  const [style, setStyle] = React.useState('cinematic, photorealistic')
  const [aspectRatio, setAspectRatio] = React.useState<'16:9' | '9:16' | '1:1'>('16:9')
  const [sceneCount, setSceneCount] = React.useState(4)
  const [loading, setLoading] = React.useState(false)
  const [storyboard, setStoryboard] = React.useState<VideoStoryboard | null>(null)
  const [isPlaying, setIsPlaying] = React.useState(false)
  const [currentScene, setCurrentScene] = React.useState(0)

  const canvasRef = React.useRef<HTMLCanvasElement | null>(null)
  const playTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null)
  const imagesRef = React.useRef<HTMLImageElement[]>([])

  const stop = React.useCallback(() => {
    if (playTimerRef.current) {
      clearTimeout(playTimerRef.current)
      playTimerRef.current = null
    }
    setIsPlaying(false)
  }, [])

  React.useEffect(() => () => stop(), [stop])

  const drawScene = (sceneIdx: number) => {
    const canvas = canvasRef.current
    if (!canvas || !storyboard) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const scene = storyboard.scenes[sceneIdx]
    const img = imagesRef.current[sceneIdx]
    const w = canvas.width
    const h = canvas.height

    // Clear with background
    ctx.fillStyle = '#000'
    ctx.fillRect(0, 0, w, h)

    // Draw image
    if (img && img.complete && img.naturalWidth > 0) {
      const imgRatio = img.naturalWidth / img.naturalHeight
      const canvasRatio = w / h
      let dw, dh, dx, dy
      if (imgRatio > canvasRatio) {
        dh = h
        dw = h * imgRatio
        dx = (w - dw) / 2
        dy = 0
      } else {
        dw = w
        dh = w / imgRatio
        dx = 0
        dy = (h - dh) / 2
      }
      ctx.drawImage(img, dx, dy, dw, dh)
    } else {
      // Gradient placeholder
      const grad = ctx.createLinearGradient(0, 0, w, h)
      grad.addColorStop(0, '#1a1a2e')
      grad.addColorStop(1, '#16213e')
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, w, h)
    }

    // Vignette
    const vignette = ctx.createRadialGradient(w / 2, h / 2, w * 0.3, w / 2, h / 2, w * 0.7)
    vignette.addColorStop(0, 'rgba(0,0,0,0)')
    vignette.addColorStop(1, 'rgba(0,0,0,0.5)')
    ctx.fillStyle = vignette
    ctx.fillRect(0, 0, w, h)

    // Caption
    ctx.font = 'bold 22px sans-serif'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    const text = scene.caption
    const metrics = ctx.measureText(text)
    const padX = 20
    const padY = 12
    const boxW = metrics.width + padX * 2
    const boxH = 36
    const boxX = (w - boxW) / 2
    const boxY = h - boxH - 30

    ctx.fillStyle = 'rgba(0,0,0,0.7)'
    ctx.fillRect(boxX, boxY, boxW, boxH)
    ctx.fillStyle = '#fff'
    ctx.fillText(text, w / 2, boxY + boxH / 2)

    // Scene counter
    ctx.font = '14px monospace'
    ctx.textAlign = 'left'
    ctx.fillStyle = 'rgba(255,255,255,0.6)'
    ctx.fillText(`${sceneIdx + 1} / ${storyboard.scenes.length}`, 16, 24)

    // Title (top center)
    ctx.font = 'bold 16px sans-serif'
    ctx.textAlign = 'center'
    ctx.fillStyle = 'rgba(255,255,255,0.8)'
    ctx.fillText(storyboard.title.toUpperCase(), w / 2, 24)
  }

  const play = () => {
    if (!storyboard || storyboard.scenes.length === 0) return
    stop()
    setIsPlaying(true)
    let idx = 0
    setCurrentScene(0)
    drawScene(0)

    const advance = () => {
      idx += 1
      if (idx >= storyboard.scenes.length) {
        setIsPlaying(false)
        return
      }
      setCurrentScene(idx)
      drawScene(idx)
      const dur = storyboard.scenes[idx].duration * 1000
      playTimerRef.current = setTimeout(advance, dur)
    }

    playTimerRef.current = setTimeout(advance, storyboard.scenes[0].duration * 1000)
  }

  // Preload images whenever storyboard changes
  React.useEffect(() => {
    if (!storyboard) {
      imagesRef.current = []
      return
    }
    imagesRef.current = storyboard.scenes.map((s) => {
      const img = new Image()
      if (s.imageBase64) img.src = s.imageBase64
      img.onload = () => {
        if (currentScene === s.id - 1) drawScene(currentScene)
      }
      return img
    })
    // draw first scene after a brief delay
    setTimeout(() => drawScene(0), 100)
  }, [storyboard])

  React.useEffect(() => {
    drawScene(currentScene)
  }, [currentScene])

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt first')
      return
    }
    stop()
    setLoading(true)
    setStoryboard(null)
    setCurrentScene(0)
    try {
      const res = await fetch('/api/generate/video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, style, aspectRatio, sceneCount }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to generate video')
      setStoryboard(data.storyboard)
      toast.success(`Generated "${data.storyboard.title}" with ${data.storyboard.scenes.length} scenes`)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Unknown error')
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadFrames = () => {
    if (!storyboard) return
    storyboard.scenes.forEach((s, i) => {
      if (!s.imageBase64) return
      const a = document.createElement('a')
      a.href = s.imageBase64
      a.download = `frame-${i + 1}.png`
      a.click()
    })
    toast.success('Exported scene frames')
  }

  const aspectClass =
    aspectRatio === '16:9' ? 'aspect-video' :
    aspectRatio === '9:16' ? 'aspect-[9/16] max-w-[320px] mx-auto' :
    'aspect-square max-w-[480px] mx-auto'

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="size-5 text-primary" />
            Video Storyboard
          </CardTitle>
          <CardDescription>
            Describe a video concept. The AI will storyboard it into scenes, generate cinematic images for each, and play them back as a video sequence.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="video-prompt">Prompt</Label>
            <Textarea
              id="video-prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. A timelapse of a flower blooming in a sunlit garden"
              className="min-h-[100px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Visual Style</Label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="cinematic, photorealistic">Cinematic Photorealistic</SelectItem>
                <SelectItem value="anime, cel-shaded">Anime</SelectItem>
                <SelectItem value="watercolor illustration">Watercolor</SelectItem>
                <SelectItem value="3D rendered, pixar style">3D Pixar Style</SelectItem>
                <SelectItem value="noir, black and white">Film Noir</SelectItem>
                <SelectItem value="vibrant cyberpunk">Cyberpunk</SelectItem>
                <SelectItem value="vintage film grain">Vintage Film</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Aspect Ratio</Label>
              <Select value={aspectRatio} onValueChange={(v) => setAspectRatio(v as '16:9' | '9:16' | '1:1')}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="16:9">16:9 Landscape</SelectItem>
                  <SelectItem value="9:16">9:16 Portrait</SelectItem>
                  <SelectItem value="1:1">1:1 Square</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Scenes: {sceneCount}</Label>
              <Select value={String(sceneCount)} onValueChange={(v) => setSceneCount(Number(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 scenes</SelectItem>
                  <SelectItem value="4">4 scenes</SelectItem>
                  <SelectItem value="5">5 scenes</SelectItem>
                  <SelectItem value="6">6 scenes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={handleGenerate} disabled={loading} className="w-full">
            {loading ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Directing & rendering scenes...
              </>
            ) : (
              <>
                <Sparkles className="size-4" />
                Generate Video
              </>
            )}
          </Button>
          <p className="text-xs text-muted-foreground">
            Note: Each scene uses real AI image generation. A 4-scene video typically takes 30-60 seconds.
          </p>
        </CardContent>
      </Card>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Film className="size-5 text-primary" />
              Player
            </span>
            {storyboard && (
              <Button variant="outline" size="sm" onClick={handleDownloadFrames}>
                <Download className="size-4" />
                Frames
              </Button>
            )}
          </CardTitle>
          <CardDescription>
            {storyboard ? `"${storyboard.title}" — ${storyboard.scenes.length} scenes` : 'Your video will appear here.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!storyboard && !loading && (
            <div className="flex flex-col items-center justify-center h-72 text-center text-muted-foreground">
              <Video className="size-12 mb-3 opacity-30" />
              <p className="text-sm">Generate a storyboard to preview.</p>
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center h-72 gap-3">
              <Loader2 className="size-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Generating cinematic frames...</p>
            </div>
          )}

          {storyboard && (
            <div className="space-y-3">
              <div className={`relative overflow-hidden rounded-lg bg-black border border-border/60 ${aspectClass}`}>
                <canvas
                  ref={canvasRef}
                  width={aspectRatio === '9:16' ? 720 : 960}
                  height={aspectRatio === '9:16' ? 1280 : aspectRatio === '1:1' ? 960 : 540}
                  className="w-full h-full"
                />
              </div>

              <div className="flex items-center gap-2">
                <Button onClick={isPlaying ? stop : play} size="sm">
                  {isPlaying ? <Pause className="size-4" /> : <Play className="size-4" />}
                  {isPlaying ? 'Pause' : 'Play'}
                </Button>
                <span className="text-xs text-muted-foreground">
                  Scene {currentScene + 1} / {storyboard.scenes.length}
                </span>
              </div>

              <div className="flex gap-2 overflow-x-auto nice-scroll pb-1">
                {storyboard.scenes.map((s, i) => (
                  <button
                    key={s.id}
                    onClick={() => { stop(); setCurrentScene(i); drawScene(i) }}
                    className={`shrink-0 size-16 rounded-md overflow-hidden border-2 ${i === currentScene ? 'border-primary' : 'border-transparent'}`}
                    title={s.caption}
                  >
                    {s.imageBase64 ? (
                      <img src={s.imageBase64} alt={s.caption} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-muted flex items-center justify-center text-xs">{i + 1}</div>
                    )}
                  </button>
                ))}
              </div>

              <div className="space-y-1">
                <p className="text-sm font-medium">{storyboard.scenes[currentScene]?.caption}</p>
                <p className="text-xs text-muted-foreground line-clamp-2">{storyboard.scenes[currentScene]?.imagePrompt}</p>
              </div>

              <div className="flex flex-wrap gap-2 text-xs">
                <Badge variant="outline">{storyboard.style}</Badge>
                <Badge variant="outline">{storyboard.aspectRatio}</Badge>
                <Badge variant="outline">{storyboard.scenes.reduce((a, s) => a + s.duration, 0)}s total</Badge>
              </div>

              <div className="rounded-md bg-muted/40 p-3">
                <div className="text-xs text-muted-foreground mb-1">AI Narration</div>
                <p className="text-sm italic">{storyboard.audioNarration}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
