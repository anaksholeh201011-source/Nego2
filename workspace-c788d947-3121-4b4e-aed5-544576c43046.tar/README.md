# NexusAI Studio — Generate Anything

An open-source, all-in-one AI creation studio that turns a single text prompt into **music**, **videos**, **playable games**, and **interactive 3D models** — all in the browser, no installs required.

Built on Next.js 16, Three.js, Web Audio API, and the GLM multimodal AI model.

---

## Features

| Generator | What it does | Tech |
| --- | --- | --- |
| **Music** | Composes a multi-track piece (bass, harmony, melody, percussion) from a text prompt and synthesizes it live with the Web Audio API. | LLM → JSON notes → Web Audio oscillators |
| **Video** | Storyboards a concept into 3-6 cinematic scenes, generates a real AI image for each scene, then plays them back as a sequenced video with captions and transitions. | LLM storyboard → Image gen per scene → Canvas playback |
| **Game** | Generates a complete, self-contained, runnable HTML5 canvas game from your description. Plays instantly in a sandboxed iframe. | LLM → full HTML+JS+CSS game code → iframe |
| **3D Model** | Composes a 3D scene from primitive geometries (box, sphere, cylinder, torus, etc.) based on your prompt and renders an interactive, orbitable model. | LLM → scene JSON → Three.js renderer |

Every generation is saved to a local SQLite database so you can revisit your history.

---

## Quick Start

```bash
# 1. Install dependencies
bun install

# 2. Configure your Z.AI credentials
#    Create a .z-ai-config file in the project root:
cat > .z-ai-config <<EOF
{
  "baseUrl": "https://open.bigmodel.cn/api/paas/v4",
  "apiKey": "YOUR_ZAI_API_KEY"
}
EOF

# 3. Push the database schema
bun run db:push

# 4. Start the dev server
bun run dev
```

Open <http://localhost:3000> and start generating.

---

## Project Structure

```
.
├── prisma/
│   └── schema.prisma            # SQLite schema (Generation model)
├── public/                      # Static assets
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   └── generate/
│   │   │       ├── music/route.ts       # LLM → music JSON
│   │   │       ├── video/route.ts       # LLM storyboard + image gen
│   │   │       ├── game/route.ts        # LLM → HTML5 game code
│   │   │       └── model3d/route.ts     # LLM → Three.js scene JSON
│   │   ├── globals.css         # Theme tokens + custom styles
│   │   ├── layout.tsx          # Root layout + theme provider
│   │   └── page.tsx            # Studio UI (tabs, hero, footer)
│   ├── components/
│   │   ├── generators/
│   │   │   ├── music-generator.tsx      # Web Audio synthesizer
│   │   │   ├── video-generator.tsx      # Canvas video player
│   │   │   ├── game-generator.tsx       # iframe game renderer
│   │   │   └── model3d-generator.tsx    # Three.js viewport
│   │   ├── theme-provider.tsx
│   │   └── ui/                  # shadcn/ui components
│   └── lib/
│       ├── db.ts                # Prisma client
│       ├── utils.ts             # cn() helper
│       └── zai.ts               # Z.AI SDK singleton + JSON extractor
├── Caddyfile                    # Gateway config (used by sandbox)
├── package.json
└── README.md
```

---

## How it works

### 1. Music generator
The user submits a prompt, genre, mood, and duration. The backend calls the LLM with a strict JSON schema and asks for a multi-track composition (notes with frequency, time, duration, instrument, velocity). The frontend uses the Web Audio API to schedule oscillators with attack/decay/sustain/release envelopes — real audio, no audio files needed.

### 2. Video generator
The LLM plans a storyboard (3-6 scenes, each with an image prompt, caption, duration, and transition). For each scene, the backend calls the Z.AI image generation API in parallel and returns base64 PNGs. The frontend renders the sequence on a `<canvas>` with captions, vignette, and a scene counter — like a slideshow video.

### 3. Game generator
The LLM is prompted to emit a complete HTML document (with embedded `<style>` and `<script>`) that implements a playable game using vanilla JS + canvas. The frontend renders it in a sandboxed `<iframe srcDoc>` so the generated code can run safely with keyboard/touch input.

### 4. 3D model generator
The LLM emits a JSON scene description (objects, materials, lights, camera, auto-rotate). The frontend builds a Three.js scene from primitives — box, sphere, cylinder, cone, torus, octahedron, icosahedron, torus knot — with standard/phong/basic/wireframe materials, ambient + directional lighting, and mouse-drag orbit control.

---

## Tech Stack

- **Framework**: Next.js 16 (App Router) + TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui (New York) + Framer Motion
- **Database**: Prisma ORM + SQLite
- **AI**: `z-ai-web-dev-sdk` (GLM chat completions + image generation)
- **3D**: Three.js
- **Audio**: Web Audio API (browser-native)
- **Icons**: Lucide React
- **Theme**: next-themes (dark/light mode)

---

## Configuration

### Z.AI credentials

The app expects a `.z-ai-config` file in the project root, the home directory, or `/etc/`:

```json
{
  "baseUrl": "https://open.bigmodel.cn/api/paas/v4",
  "apiKey": "YOUR_API_KEY"
}
```

Get a key at <https://z.ai>.

### Environment variables

Create a `.env` file:

```env
DATABASE_URL="file:/path/to/custom.db"
```

---

## API Reference

| Endpoint | Method | Body | Returns |
| --- | --- | --- | --- |
| `/api/generate/music` | POST | `{ prompt, genre?, mood?, duration? }` | `{ track: MusicTrack }` |
| `/api/generate/video` | POST | `{ prompt, style?, aspectRatio?, sceneCount? }` | `{ storyboard: VideoStoryboard }` (scenes include base64 images) |
| `/api/generate/game` | POST | `{ prompt, gameType? }` | `{ game: GameResult }` (includes full HTML) |
| `/api/generate/model3d` | POST | `{ prompt, complexity? }` | `{ scene: Model3DScene }` |

---

## Roadmap

- [ ] Real video generation via Z.AI video API (currently uses image sequences)
- [ ] User accounts + saved generation library
- [ ] Export music as WAV
- [ ] Export 3D models as GLTF/GLB
- [ ] Multiplayer game generation
- [ ] Plugin system for custom generators

---

## License

MIT — see [LICENSE](./LICENSE).

---

## Contributing

PRs welcome. Please open an issue first to discuss what you'd like to change.

Built with care using Z.AI's GLM multimodal models.
